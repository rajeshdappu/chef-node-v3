execute 'Update NPM to latest' do
  command 'npm install -g npm'
end
